<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가
?>

<!-- TODO :  LayerPopup의 Target DIV 생성 -->
<script>
$(function() {
    $("body").append('<div id="kakaopay_layer"  style="display: none"></div>');
});
</script>